document.addEventListener('DOMContentLoaded', () => {
    // --- SELETORES DOS ELEMENTOS DO DOM ---
    const modalContainer = document.getElementById('modal-container');
    const modalBody = document.getElementById('modal-body');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const btnAbrirModalAdicionar = document.getElementById('btn-abrir-modal-adicionar');
    const tabelaCorpo = document.querySelector('#tabela-estoque tbody');
    const filtroNomeInput = document.getElementById('filtro-nome');
    const filtroLoteInput = document.getElementById('filtro-lote');
    const filtroCategoria = document.getElementById('filtro-categoria');
    const limparFiltrosBtn = document.getElementById('limpar-filtros');
    const btnAgruparLote = document.getElementById('btn-agrupar-lote');
    const btnVoltarAgrupamento = document.getElementById('btn-voltar-agrupamento');
    const btnExportar = document.getElementById('btn-exportar');
    const listaNotificacoes = document.getElementById('lista-notificacoes');
    const validadeList = document.getElementById('validade-list');
    const totalItensSpan = document.getElementById('total-itens');
    const totalUnidadesSpan = document.getElementById('total-unidades');

    // --- ESTADO DA APLICAÇÃO ---
    const CATEGORIAS = ['Grãos', 'Laticínios', 'Hortifruti', 'Carnes', 'Congelados', 'Limpeza', 'Outros'];
    let estoque = [];
    let notificacoes = [];
    let editandoId = null;

    // --- FUNÇÕES DE DADOS E SINCRONIZAÇÃO ---
    const carregarDados = () => {
        let estoqueSalvo = JSON.parse(localStorage.getItem('estoque')) || [];
        notificacoes = JSON.parse(localStorage.getItem('notificacoes')) || [];

        let dadosMigrados = false;
        estoqueSalvo.forEach((item, index) => {
            if (!item.id) {
                item.id = Date.now() + index;
                dadosMigrados = true;
            }
        });
        
        estoque = estoqueSalvo;

        if (dadosMigrados) {
            salvarDados();
        }

        CATEGORIAS.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            filtroCategoria.appendChild(option);
        });

        atualizarTelaToda();
    };

    const salvarDados = () => {
        localStorage.setItem('estoque', JSON.stringify(estoque));
        localStorage.setItem('notificacoes', JSON.stringify(notificacoes));
    };

    const atualizarTelaToda = () => {
        aplicarFiltros();
        exibirNotificacoes();
        gerarResumoGeral();
        gerarDashboardValidade();
        verificarAlertas();
    };

    // --- FUNÇÕES DO MODAL ---
    const abrirModal = () => modalContainer.classList.remove('hidden');
    const fecharModal = () => modalContainer.classList.add('hidden');

    const montarModalAdicionarEditar = (item = {}) => {
        editandoId = item.id || null;
        const ehEdicao = Boolean(item.id);
        const opcoesCategoria = CATEGORIAS.map(cat => 
            `<option value="${cat}" ${item.categoria === cat ? 'selected' : ''}>${cat}</option>`
        ).join('');

        modalBody.innerHTML = `
            <h3>${ehEdicao ? 'Editar Item' : 'Adicionar Novo Item'}</h3>
            <form id="modal-form">
                <label for="nome-alimento">Nome do Alimento:</label>
                <input type="text" id="nome-alimento" value="${item.nome || ''}" required>
                <label for="categoria-item">Categoria:</label>
                <select id="categoria-item" required>
                    <option value="" disabled ${!item.categoria ? 'selected' : ''}>Selecione...</option>
                    ${opcoesCategoria}
                </select>
                <label for="quantidade">Quantidade:</label>
                <input type="number" id="quantidade" value="${item.quantidade || ''}" required min="0">
                <label for="lote">Número do Lote:</label>
                <input type="text" id="lote" value="${item.lote || ''}">
                <label for="quantidade-minima">Estoque Mínimo:</label>
                <input type="number" id="quantidade-minima" value="${item.quantidadeMinima || 0}" min="0">
                <label for="validade">Data de Validade:</label>
                <input type="date" id="validade" value="${item.validade || ''}">
                <button type="submit">${ehEdicao ? 'Atualizar' : 'Salvar Item'}</button>
            </form>
        `;
        abrirModal();
        document.getElementById('modal-form').addEventListener('submit', salvarItemDoModal);
    };

    const montarModalEntradaSaida = (id, tipo) => {
        const item = estoque.find(i => i.id === id);
        if (!item) return;
        const corBotao = tipo === 'entrada' ? 'var(--cor-sucesso)' : 'var(--cor-alerta)';
        modalBody.innerHTML = `
            <h3>Registrar ${tipo === 'entrada' ? 'Entrada de' : 'Saída de'} <strong>${item.nome}</strong></h3>
            <p>Estoque atual: <strong>${item.quantidade}</strong></p>
            <form id="form-movimentacao">
                <label for="quantidade-mov">Quantidade:</label>
                <input type="number" id="quantidade-mov" required min="1" autofocus>
                <div class="botoes-modal">
                    <button type="submit" style="background-color: ${corBotao};">Confirmar</button>
                </div>
            </form>
        `;
        abrirModal();
        document.getElementById('form-movimentacao').addEventListener('submit', (e) => {
            e.preventDefault();
            const quantidade = parseInt(document.getElementById('quantidade-mov').value, 10);
            if(isNaN(quantidade) || quantidade <= 0) return alert('Quantidade inválida.');
            if (tipo === 'saida' && quantidade > item.quantidade) return alert('Quantidade de saída maior que o estoque.');
            item.quantidade += (tipo === 'entrada' ? quantidade : -quantidade);
            if (item.quantidade > item.quantidadeMinima) item.alertaGerado = false;
            salvarDados();
            atualizarTelaToda();
            fecharModal();
        });
    };

    // --- FUNÇÕES DE CRUD E AÇÕES ---
    const salvarItemDoModal = (event) => {
        event.preventDefault();
        const data = {
            nome: document.getElementById('nome-alimento').value.trim(),
            categoria: document.getElementById('categoria-item').value,
            quantidade: parseInt(document.getElementById('quantidade').value, 10),
            lote: document.getElementById('lote').value.trim(),
            quantidadeMinima: parseInt(document.getElementById('quantidade-minima').value, 10) || 0,
            validade: document.getElementById('validade').value,
        };
        if (editandoId) {
            const item = estoque.find(i => i.id === editandoId);
            if (item) {
                Object.assign(item, data);
                if (item.quantidade > item.quantidadeMinima) item.alertaGerado = false;
            }
        } else {
            estoque.push({ id: Date.now(), ...data, alertaGerado: false, alertaValidadeGerado: false });
        }
        salvarDados();
        atualizarTelaToda();
        fecharModal();
    };

    const manipularAcoesTabela = (e) => {
        const botao = e.target.closest('.btn-acao-icone');
        if (!botao) return;
        const id = Number(botao.dataset.id);
        const acao = botao.dataset.acao;
        const item = estoque.find(i => i.id === id);
        if (!item) return;

        if (acao === 'editar') montarModalAdicionarEditar(item);
        if (acao === 'entrada' || acao === 'saida') montarModalEntradaSaida(id, acao);
        if (acao === 'excluir') {
            if (confirm(`Tem certeza que deseja excluir o item "${item.nome}"?`)) {
                estoque = estoque.filter(i => i.id !== id);
                salvarDados();
                atualizarTelaToda();
            }
        }
    };
    
    // --- FUNÇÕES DE EXIBIÇÃO E RENDERIZAÇÃO ---
    const exibirEstoque = (lista = estoque) => {
        tabelaCorpo.innerHTML = '';
        btnVoltarAgrupamento.classList.add('hidden');
        btnAgruparLote.classList.remove('hidden');
        if (lista.length === 0) {
            tabelaCorpo.innerHTML = '<tr><td colspan="6">Nenhum item encontrado.</td></tr>';
            return;
        }
        lista.forEach(item => {
            const tr = document.createElement('tr');
            if (item.quantidade <= item.quantidadeMinima && item.quantidadeMinima > 0) tr.classList.add('estoque-baixo');
            const dataValidade = item.validade ? new Date(item.validade + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A';
            tr.innerHTML = `
                <td>${item.nome}</td>
                <td>${item.categoria || 'N/A'}</td>
                <td>${item.quantidade}</td>
                <td>${item.lote || 'N/A'}</td>
                <td>${dataValidade}</td>
                <td class="botoes-tabela">
                    <button class="btn-acao-icone entrada" data-id="${item.id}" data-acao="entrada" title="Registrar Entrada"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/></svg></button>
                    <button class="btn-acao-icone saida" data-id="${item.id}" data-acao="saida" title="Registrar Saída"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M2 8a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11A.5.5 0 0 1 2 8Z"/></svg></button>
                    <button class="btn-acao-icone editar" data-id="${item.id}" data-acao="editar" title="Editar Item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/></svg></button>
                    <button class="btn-acao-icone excluir" data-id="${item.id}" data-acao="excluir" title="Excluir Item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z"/><path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118Z"/></svg></button>
                </td>
            `;
            tabelaCorpo.appendChild(tr);
        });
    };
    
    const exibirEstoqueAgrupado = () => {
        tabelaCorpo.innerHTML = '';
        btnAgruparLote.classList.add('hidden');
        btnVoltarAgrupamento.classList.remove('hidden');
        const agrupadoPorLote = estoque.reduce((acc, item) => {
            const lote = item.lote || 'Sem Lote';
            if (!acc[lote]) acc[lote] = [];
            acc[lote].push(item);
            return acc;
        }, {});
        for (const lote in agrupadoPorLote) {
            const trLote = document.createElement('tr');
            trLote.className = 'linha-agrupamento';
            trLote.setAttribute('data-lote-header', lote);
            trLote.onclick = () => toggleAgrupamento(lote);
            trLote.innerHTML = `<td colspan="6">Lote: ${lote} (${agrupadoPorLote[lote].length} itens) <span class="toggle-icon">►</span></td>`;
            tabelaCorpo.appendChild(trLote);
            agrupadoPorLote[lote].forEach(item => {
                const trItem = document.createElement('tr');
                trItem.setAttribute('data-lote', lote);
                trItem.classList.add('hidden');
                if (item.quantidade <= item.quantidadeMinima && item.quantidadeMinima > 0) trItem.classList.add('estoque-baixo');
                const dataValidade = item.validade ? new Date(item.validade + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A';
                trItem.innerHTML = `
                    <td>${item.nome}</td><td>${item.categoria || 'N/A'}</td><td>${item.quantidade}</td><td>${item.lote || 'N/A'}</td><td>${dataValidade}</td>
                    <td class="botoes-tabela">
                        <button class="btn-acao-icone entrada" data-id="${item.id}" data-acao="entrada" title="Registrar Entrada"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/></svg></button>
                        <button class="btn-acao-icone saida" data-id="${item.id}" data-acao="saida" title="Registrar Saída"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M2 8a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11A.5.5 0 0 1 2 8Z"/></svg></button>
                        <button class="btn-acao-icone editar" data-id="${item.id}" data-acao="editar" title="Editar Item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/></svg></button>
                        <button class="btn-acao-icone excluir" data-id="${item.id}" data-acao="excluir" title="Excluir Item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z"/><path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118Z"/></svg></button>
                    </td>
                `;
                tabelaCorpo.appendChild(trItem);
            });
        }
    };
    const toggleAgrupamento = (lote) => {
        const itens = document.querySelectorAll(`[data-lote="${lote}"]`);
        itens.forEach(item => item.classList.toggle('hidden'));
        const icon = document.querySelector(`[data-lote-header="${lote}"] .toggle-icon`);
        if (icon) icon.textContent = itens[0].classList.contains('hidden') ? '►' : '▼';
    };

    // --- FUNÇÕES DE DASHBOARD, NOTIFICAÇÕES E ALERTAS ---
    const gerarResumoGeral = () => {
        totalItensSpan.textContent = estoque.length;
        totalUnidadesSpan.textContent = estoque.reduce((soma, item) => soma + (item.quantidade || 0), 0);
    };
    const gerarDashboardValidade = () => {
        const hoje = new Date();
        const trintaDias = new Date();
        trintaDias.setDate(hoje.getDate() + 30);
        validadeList.innerHTML = '';
        const itensVencendo = estoque.filter(item => {
            if (!item.validade) return false;
            const validadeItem = new Date(item.validade + 'T00:00:00');
            return validadeItem <= trintaDias && validadeItem >= hoje;
        }).sort((a, b) => new Date(a.validade) - new Date(b.validade));
        if (itensVencendo.length === 0) {
            validadeList.innerHTML = '<p class="sem-itens">Nenhum item próximo de vencer.</p>';
            return;
        }
        const ul = document.createElement('ul');
        itensVencendo.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.nome} (Lote: ${item.lote || 'N/A'}) vence em ${new Date(item.validade + 'T00:00:00').toLocaleDateString('pt-BR')}`;
            ul.appendChild(li);
        });
        validadeList.appendChild(ul);
    };
    const exibirNotificacoes = () => {
        listaNotificacoes.innerHTML = '';
        if (notificacoes.length === 0) {
            listaNotificacoes.innerHTML = '<p class="sem-notificacoes">Nenhuma notificação.</p>';
            return;
        }
        notificacoes.forEach((notificacao, index) => {
            const div = document.createElement('div');
            div.className = 'notificacao-item';
            div.innerHTML = `<p>${notificacao.mensagem}</p><button class="btn-remover-notificacao" data-index="${index}">X</button>`;
            listaNotificacoes.appendChild(div);
        });
    };
    const verificarAlertas = () => {
        let novaNotificacao = false;
        estoque.forEach(item => {
            if (item.quantidadeMinima > 0 && item.quantidade <= item.quantidadeMinima && !item.alertaGerado) {
                gerarAlerta(`Estoque baixo: ${item.nome} (Lote: ${item.lote}) atingiu ${item.quantidade} unidades.`);
                item.alertaGerado = true;
                novaNotificacao = true;
            }
            if (item.validade && !item.alertaValidadeGerado) {
                const hoje = new Date();
                const validadeItem = new Date(item.validade + 'T00:00:00');
                const diffDias = Math.ceil((validadeItem - hoje) / (1000 * 60 * 60 * 24));
                if (diffDias <= 30 && diffDias >= 0) {
                    gerarAlerta(`Validade próxima: ${item.nome} (Lote: ${item.lote}) vence em ${diffDias} dia(s).`);
                    item.alertaValidadeGerado = true;
                    novaNotificacao = true;
                }
            }
        });
        if (novaNotificacao) {
            salvarDados();
            exibirNotificacoes();
        }
    };
    const gerarAlerta = (mensagem) => {
        const dataHora = new Date().toLocaleString('pt-BR');
        notificacoes.unshift({ mensagem: `[${dataHora}] ${mensagem}` });
    };
    const removerNotificacao = (index) => {
        notificacoes.splice(index, 1);
        salvarDados();
        exibirNotificacoes();
    };
    
    // --- FUNÇÕES DE FILTRO E EXPORTAÇÃO ---
    const aplicarFiltros = () => {
        const nome = (document.getElementById('filtro-nome')).value.toLowerCase();
        const lote = filtroLoteInput.value.toLowerCase();
        const categoria = filtroCategoria.value;
        
        const estoqueFiltrado = estoque.filter(item => {
            const nomeMatch = item.nome.toLowerCase().includes(nome);
            const loteMatch = (item.lote || '').toLowerCase().includes(lote);
            const categoriaMatch = !categoria || item.categoria === categoria;
            return nomeMatch && loteMatch && categoriaMatch;
        });
        exibirEstoque(estoqueFiltrado);
    };
    const limparFiltros = () => {
        (document.getElementById('filtro-nome')).value = '';
        filtroLoteInput.value = '';
        filtroCategoria.value = '';
        aplicarFiltros();
    };
    const exportarRelatorioCSV = () => {
        if (estoque.length === 0) return alert("Estoque vazio, nada para exportar.");
        const separador = ';';
        const cabecalho = ['ID', 'Nome', 'Categoria', 'Quantidade', 'Lote', 'Estoque Minimo', 'Data de Validade'];
        const linhas = estoque.map(item => [
            item.id,
            `"${item.nome.replace(/"/g, '""')}"`,
            `"${item.categoria || 'N/A'}"`,
            item.quantidade,
            `"${(item.lote || '').replace(/"/g, '""')}"`,
            item.quantidadeMinima,
            item.validade ? `"${new Date(item.validade + 'T00:00:00').toLocaleDateString('pt-BR')}"` : '"N/A"'
        ]);
        let csvContent = [cabecalho.join(separador), ...linhas.map(e => e.join(separador))].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'relatorio_estoque.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    // --- EVENT LISTENERS ---
    btnAbrirModalAdicionar.addEventListener('click', () => montarModalAdicionarEditar());
    closeModalBtn.addEventListener('click', fecharModal);
    modalContainer.addEventListener('click', (e) => { if (e.target === modalContainer) fecharModal(); });
    tabelaCorpo.addEventListener('click', manipularAcoesTabela);
    (document.getElementById('filtro-nome')).addEventListener('input', aplicarFiltros);
    filtroLoteInput.addEventListener('input', aplicarFiltros);
    filtroCategoria.addEventListener('change', aplicarFiltros);
    limparFiltrosBtn.addEventListener('click', limparFiltros);
    btnAgruparLote.addEventListener('click', exibirEstoqueAgrupado);
    btnVoltarAgrupamento.addEventListener('click', () => aplicarFiltros());
    btnExportar.addEventListener('click', exportarRelatorioCSV);
    listaNotificacoes.addEventListener('click', (e) => {
        const botaoRemover = e.target.closest('.btn-remover-notificacao');
        if (botaoRemover) {
            removerNotificacao(Number(botaoRemover.dataset.index));
        }
    });

    // --- INICIALIZAÇÃO DA APLICAÇÃO ---
    carregarDados();
});